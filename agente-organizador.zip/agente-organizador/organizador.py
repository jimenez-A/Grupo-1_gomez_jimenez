import os
import json
import shutil
from pathlib import Path

def escanear_carpeta(ruta_carpeta: str) -> list[str]:
    carpeta = Path(ruta_carpeta)
    if not carpeta.exists(): return []
    return [f.name for f in carpeta.iterdir() if f.is_file()]

def clasificar_con_claude(archivos: list[str]) -> dict:
    # Simulador para que funcione sin API Key por ahora
    clasificacion = {}
    for archivo in archivos:
        ext = Path(archivo).suffix.lower()
        if ext in ['.pdf', '.docx', '.txt']: clasificacion[archivo] = "documentos"
        elif ext in ['.jpg', '.png', '.jpeg']: clasificacion[archivo] = "imagenes"
        else: clasificacion[archivo] = "otros"
    return clasificacion

def mover_archivos(ruta_carpeta: str, clasificacion: dict) -> dict:
    carpeta = Path(ruta_carpeta)
    estadisticas = {}
    for archivo, categoria in clasificacion.items():
        origen = carpeta / archivo
        destino_dir = carpeta / categoria
        destino_dir.mkdir(exist_ok=True)
        shutil.move(str(origen), str(destino_dir / archivo))
        estadisticas[categoria] = estadisticas.get(categoria, 0) + 1
    return estadisticas

def mostrar_plan(clasificacion: dict) -> None:
    print("\n" + "=" * 55)
    print("📋 PLAN DE ORGANIZACIÓN")
    print("=" * 55)
    for archivo, categoria in clasificacion.items():
        print(f"📁 {categoria}/ └── {archivo}")

def main():
    print("=" * 55)
    print("🐍 AGENTE ORGANIZADOR DE ARCHIVOS CON IA")
    print("=" * 55)
    
    ruta = "desordenada"
    archivos = escanear_carpeta(ruta)
    
    if not archivos:
        print("\n🛑 No hay archivos para organizar.")
        return
    
    clasificacion = clasificar_con_claude(archivos)
    mostrar_plan(clasificacion)
    
    respuesta = input("\n¿Deseas ejecutar este plan? (s/n): ").strip().lower()
    
    if respuesta == "s":
        mover_archivos(ruta, clasificacion)
        print("\n🎉 ¡ORGANIZACIÓN COMPLETADA!")
    else:
        print("\n🚫 Operación cancelada.")

if __name__ == "__main__":
    main()
    